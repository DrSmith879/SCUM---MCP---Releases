SCUM - MCP  v0.5.1
Copyright (c) 2026 Whiteleyj. All rights reserved. Proprietary; see LICENSE.txt.
===============================================================================

WHAT THIS IS
  The SCUM - MCP desktop app (Windows 10/11, 64-bit). It runs fully offline and
  separate from any online AI: no internet, no account. Everything it needs is in
  this folder. One app for both the SCUM dedicated server and the SCUM game client.
  Online steps exist only where they must (SteamCMD download, game updates, the
  optional update check) and run only when you press their button.

LOOK AND FEEL
  - Green accent, dark theme (Light theme in Settings > General).
  - Every box can be minimized and starts minimized: click its title.
  - Every switch reads On / Off: green = On, red = Off.
  - Top bar on each screen: search, Metric / US-Imperial, linked m <-> ft and
    °C <-> °F converters, Load / Reset / Save & Apply.
  - Left menu: ADMIN (Client Panel, Server Panel), Population Controller,
    Developer Mode, Crosshair, Mod Manager (UE4SS, MCP Bridge, UE4SS Mods,
    PAK Mods, Add-ons / Plugins), Discord (future), Settings. ADMIN and Mod
    Manager fold open and closed with their arrow. Status box at the bottom
    with one card per install.

WHAT'S NEW IN v0.5.1
  - Scum Crosshair is a client-side UI mod: it now installs to the Client
    only, with no Server or Both choice.
  - Every mod has a side: Client (UI, HUD, visuals), Server (spawning, loot,
    admin, SCUM.db; Client allowed for single-player) or Both (UE4SS, paks
    that add new assets). Mods say this in plugin.json ("side"); the app also
    knows the MCP mods that don't say it yet.
  - Population Controller > Spawn diagram: shows the in-sight removal
    distance (for example 1000 m) as well as the out-of-sight ones.

WHAT'S NEW IN v0.5.0
  - Updates: Settings > App Updates > Check for updates reads the newest
    release from GitHub (DrSmith879/SCUM---MCP---Releases) and downloads only
    the parts that changed (app, runtime or bundled mods). Every file is
    checked against the signed release list; replaced files are backed up and
    Roll back puts them back. Nothing goes online unless you press the button
    ("Check at startup" is Off by default). A release folder downloaded by
    hand can be installed offline the same way.
  - The app is now a folder of files (SCUM-MCP.exe plus its runtime) instead of
    one large exe, so updates stay small. Keep the whole SCUM-MCP folder
    together, in a folder you can write to (for example C:\SCUM\SCUM-MCP).

WHAT'S NEW IN v0.4.0
  - ADMIN > Client Panel (part of the app): launch SCUM Vanilla (BattlEye on,
    client mods off, started through Steam) or Modded (-fileopenlog
    -nobattleye, started straight from SCUM.exe so BattlEye can't block
    UE4SS's dwmapi.dll); the client's .pak mods with Install PAK(s),
    Remove, Back up all and Refresh. Launch Options moved here from Mod Manager.
  - ADMIN > Server Panel v0.1.0 (separate module, comes preinstalled): see below.
  - Settings > Modules: remove or reinstall any module (Settings, Mod Manager
    and Client Panel are part of the app and stay).
  - "SSA Bridge" is now "MCP Bridge" (our own bridge, coming later).
  - Mod Manager's menu group can be folded.

BUILT-IN MODULES (preinstalled)
  Server Panel v0.1.0 (dedicated server on this PC)
    - Start, Restart, Stop (safe: same as Ctrl+C, the server saves first),
      Force stop, Backup now, Backups, Validate files and Check & update
      (open Settings > Game Updates; online only when you press it there)
    - Vitals: status, players X / max, CPU, memory, uptime
    - Operations: next restart, skip next restart, last backup, backups
      count and size, installed game version and Steam build, crash recovery
    - World: settings from ServerSettings.ini, counts from the last save
      (SCUM.db); live weather / clock / match need MCP Bridge (later)
    - Server history chart (6h / 24h / 7d / 30d; one sample a minute while
      the app is open), live SCUM.log, players online, recent activity
    - Tabs: Controls & Schedule (launch options, daily restarts, crash
      recovery, automatic backups), Players (from SCUM.db), Chat (from the
      chat logs), Backups (world backup + restore), Logs, Monitoring.
      Live Map, Squads, Economy, Leaderboards and Broadcast need MCP Bridge.
  Population Controller v0.9.92 (server or single-player)
    - Install & status: mod and wilderness NPC pak, each to Client, Server or
      Both; NPCPAK status row; last-run summary
    - Required Server Settings panel: live values with a Copy button each
    - World cap & players (1-128, warning above 64), base zombies per player,
      buffers, NPCs per player + fixed
    - Server limits: linked sliders for zombies, NPCs, animals, birds, drones,
      with locks and a stacked total bar against the world cap
    - Cull distances (0-1000 m) and armed NPC level spawn chance (real share)
    - Settings tabs Wilderness / LTZ / MTZ / HTZ / Animals / Global / LPC, plus
      All and Spawn diagram. Every config key has a row: full name, key, the
      "-1 = game default" note, value + unit, range. Switches for on/off.
      Every distance is capped at 1000 m and shown in m or ft.
  Developer Mode v1.4.0 (server or single-player)
  Crosshair v1.0.3 (client)
  Mod Manager
    - Mod Directories with found / not-found status for each folder
    - UE4SS (official v4.0.0 release ZIP from disk), MCP Bridge status
    - Mods in Home Directory: your mod library plus the four bundled MCP
      packages, each with Install To Client / Server / Both and its status
    - UE4SS Mods (switches), PAK Mods, Add-ons / Plugins
  Settings
    - General, Startup, Game Directories, Modules, Game Updates (SteamCMD), App Updates,
      Logs & Snapshots, Compatibility, License & Activation

RUN
  1. Extract this ZIP anywhere (for example C:\SCUM\SCUM-MCP\).
  2. Double-click SCUM-MCP.exe and accept the license agreement (first run).
  3. Settings > Game Directories: set the Server folder, the Client folder, or
     both -> Save & Apply.

SAFETY
  - Nothing is changed while the server (for server changes) or the game (for
    client changes) is running.
  - Every file or folder about to be changed or removed is copied first to
    %LOCALAPPDATA%\SCUM-MCP\Backups\<Server|Client>\<date_time>\.
  - Updating a mod never overwrites its .ini or config_v*.txt settings, and a
    mod you switched off stays off.
  - Vanilla play mode only renames the client's dwmapi.dll and ~mods folder;
    Modded renames them back.

FILES
  SCUM-MCP.exe              the app (self-contained, no .NET install needed;
                            the other files in this folder are its runtime)
  release.json              which release is installed (used by updates)
  Payload\                  the bundled mods: Developer Mode v1.4.0,
                            Population Controller v0.9.92, NPC pak 0001,
                            Crosshair v1.0.3 (Client)
  LICENSE.txt               required; the app will not start if it is changed
  THIRD-PARTY-NOTICES.txt   .NET / SQLite notices

  App settings and log: %LOCALAPPDATA%\SCUM-MCP\  (settings.json, Logs\app.log)
  Add-on modules: %LOCALAPPDATA%\SCUM-MCP\Modules\<id>\module.json
